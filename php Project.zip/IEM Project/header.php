<!DOCTYPE html>
<html lang="en">
<head>
    <title>MoonDrop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
    <div class="moon">
        <img src="images\626fd458d107ab020cfa3efb_logo.svg" width="80px">
    </div>
    <div class="group">
        <ul class="m1">
            <li><a href="index.php">Home</a></li>
            <li><a href="IEMs.php">IEMs</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="register.php">Register</a></li>
        </ul>
    </div>
    <div>    
    </div>
    </header>
    